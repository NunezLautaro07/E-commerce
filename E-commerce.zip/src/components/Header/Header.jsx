import { useEffect, useState } from "react";
import "../css/style.css";

function Header ()
{
    return(
        <div>
          <nav className="navbar bg-azul">
  <div className="container-fluid ">
    <span className="navbar-brand mb-0 h py-3 fs-2 blanco ">E-commerce</span>
    <div className="derecha">
  {/* modal  bars*/}
    <button className="btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
    <i className="fa-solid fa-bars fa-2xl px-4 blanco fs-1"></i>
</button>

<div className="offcanvas offcanvas-start bg-azul " tabIndex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div className="offcanvas-header ">
    <h5 className="offcanvas-title fs-2 blanco" id="offcanvasExampleLabel">E-commerce</h5>
    <button type="button" className=" btn" data-bs-dismiss="offcanvas" aria-label="Close"><i className="fa-regular fa-circle-xmark fa-2xl fa-beat" style={{color: "#ffffff"}}></i></button>
  </div>
  <div className="offcanvas-body ">
        <a className="dropdown-item fs-5 blanco w-50" href="#">Remeras</a>
        <a className="dropdown-item fs-5 blanco my-3 w-50" href="#">Camperas</a>
        <a className="dropdown-item fs-5 blanco my-3 w-50" href="#">Calzado</a>
  </div>
</div>

{/* fin modal */}
<i className="fa-solid fa-cart-shopping fa-2xl px-4 blanco fs-2"></i>
   
    
   
    </div>
  </div>
</nav>

        </div>
    )
}
export default Header;
